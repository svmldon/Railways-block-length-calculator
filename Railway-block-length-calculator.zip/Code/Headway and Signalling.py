
# coding: utf-8

# In[ ]:


import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns


# The maximum speed (Speed_max) is taken as 80 kmph
# Braking distance (Braking_dist) 0.5 km.
# Maintenance time (Maintenance_time) is taken as 3.5 hr as the suburban line is closed from 12:30 to 4:00.
# Buffer time of 5 minutes is taken between trains

# In[ ]:


Speed_max = 80         # In kmph
Braking_dist = 0.5     # In km
Section_length = 10    # In km
Maintenance_time = 3.5 # In hr
Buffer_time = 5/60     # In hr


# Block lengths are taken from 0.5 km to 2 km with increment of 0.1 km. Changing the upper limit of block length reflects the change in plots

# In[ ]:


Block_length = np.arange(0.5,2.1,0.1)


# Function to calculate throughtput of the system using Scott's Formulae

# In[ ]:


def throughtput(time_per_train):
    no_of_trains = (24 - Maintenance_time)/(time_per_train + Buffer_time)
    return (no_of_trains)   


# Function to calculate Average Speed of the train given block length and distance between trains (in blocks) Block_b (as defined below)

# In[ ]:


def calculation(block_l,block_b):
    time_braking = (2*Braking_dist)/Speed_max
    time_running = (block_l - Braking_dist)/Speed_max
    time_freerun = ((block_b - 1)*block_l)/Speed_max 
    time_total = time_braking + time_running + time_freerun
    Speed_avg = (block_l*block_b)/time_total
    throughtput_value = throughtput(time_total)
    return (Speed_avg,throughtput_value)
    


# Function to plot Average speed vs block length and Throughput vs block length. The one set of plot (speed vs bl and throughtput vs bl) has been done for a particular spacing between trains i.e. number of blocks between trains. 

# In[ ]:


def plots(block_l,avg_speed,through,block_between):
    plt.rcParams['figure.figsize'] = [10, 5]
    plt.subplot(1, 2, 1)
    plt.plot(block_l,avg_speed)
    plt.legend(prop={'size': 16}, title = 'Block Between = '+str(block_between))
    plt.title('Block Length vs Average Speed')
    plt.xlabel('Block Length in km')
    plt.ylabel('Average Speed in kmph')
    plt.grid()
    plt.subplot(1, 2, 2)
    plt.plot(block_l,through)
    plt.legend(prop={'size': 16}, title = 'Block Between ='+str(block_between))
    plt.title('Block Length vs Throughput')
    plt.xlabel('Block Length in km')
    plt.ylabel('Throughput in no. of trains per day')
    plt.grid()
    plt.savefig('Block Between = '+str(block_between)+'.png',dpi=200)
    plt.show()


# Let number of blocks between two consecutive trains be denoted by variable Block_b.
# So if a train sees yellow signal and after that the next block is occupied by another train then Block_b = 1
# Similarly if its 4 aspect signalling and a train sees yellow signal and after that another block is empty with yellow
# signal at the starting and then red then Block_b = 2.
# If train sees green signal followed by two yellow signal then red in this case Block_b = 3.
# If two green ... then Block_b = 4

# The loop iterates number of blocks between  trains from 1 to 20 (assuming section length is 10 km so maximum no. of blocks can be (10/block length = 0.5 km). If block length is 2 km, then result of block between trains greater than 5 is no use although I have plotted the result assuming that the section length is infinite (not used section length in computation) and we can have number of blocks between two trains.

# The code saves excel file having columns block length, Average Speed and Throughput. Total 20 files gets saved on running the code where filename denotes the number of blocks between two trains.

# In[ ]:


for Block_b in range(1,21):    
    Speed_avg_yellow1 = []
    Throughput_yellow_1 = []
    for block_l in Block_length:
        #Number_of_Blocks = Section_length/block_l
        speed_avg_y1, throghput_y1 = calculation(block_l,Block_b)
        Speed_avg_yellow1.append(speed_avg_y1)
        Throughput_yellow_1.append(throghput_y1)
    #print(Speed_avg_yellow1)
    pd.DataFrame({'Block Length': Block_length, 'Average Speed': Speed_avg_yellow1, 'Throughput': Throughput_yellow_1}).to_csv("Block between = "+str(Block_b)+".csv", index=False)
    Throughput_yellow_1 = [int(x) for x in (Throughput_yellow_1)]
    #print(Throughput_yellow_1)
    plots(Block_length,Speed_avg_yellow1,Throughput_yellow_1,Block_b)

